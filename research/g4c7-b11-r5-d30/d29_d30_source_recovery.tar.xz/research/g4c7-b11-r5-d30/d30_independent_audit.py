"""D30 independent saved-GLB audit; NO generator import and NO ART certification.

Uses triangle segment intersection for limited witnesses; a single centerline does
not certify a 3-D human passage or any building code.
"""
import json, copy, argparse, math
from pathlib import Path
import numpy as np
import trimesh

def meshes(fp):
    s=trimesh.load(fp,force='scene',process=False)
    r={}
    for name in s.graph.nodes_geometry:
        T,k=s.graph[name];g=s.geometry[k].copy();g.apply_transform(T)
        r[str(name)]=g
    return r

def segment_hit(A,B,m):
    triangles=m.triangles
    if not len(triangles):return False
    A=np.array(A,float);B=np.array(B,float);d=B-A
    v0,v1,v2=triangles[:,0],triangles[:,1],triangles[:,2]
    e1=v1-v0;e2=v2-v0
    h=np.cross(np.broadcast_to(d,e2.shape),e2)
    det=np.einsum('ij,ij->i',e1,h)
    v=np.abs(det)>1e-9
    if not v.any():return False
    inv=np.zeros_like(det);inv[v]=1/det[v]
    s=A-v0;u=inv*np.einsum('ij,ij->i',s,h)
    q=np.cross(s,e1);vv=inv*np.einsum('ij,j->i',q,d)
    t=inv*np.einsum('ij,ij->i',e2,q)
    return bool(np.any(v&(u>=-1e-7)&(vv>=-1e-7)&(u+vv<=1+1e-7)&(t>1e-3)&(t<1-1e-3)))

def hits(a,b,mesh,exclude):
    return [name for name,g in mesh.items() if not name.startswith(exclude) and segment_hit(a,b,g)]

def real_bbox(ms):
    v=np.array([v for g in ms.values() for v in g.bounds])
    return [list(v.min(axis=0)),list(v.max(axis=0))]

def evaluate(m,baseline,nm,nr):
    p=m['limits']
    assert m['stage']=='B11-R5 D30'
    assert p=={'art':'ART HOLD','adopted':0,'G0':'NOT_RUN','S1_G1_G2_G3':'NOT_RUN',
      'full_body_sweep':'NOT_RUN','structural_calculation':'NOT_RUN',
      'vertical_circulation':'NOT_MODELED','construction':'FORBIDDEN',
      'city_integration':'FORBIDDEN','main':'UNTOUCHED','PR53':'OPEN_DRAFT'}
    assert set(m['cases'])=={'baseline','no_maker','no_research'}
    must=['maker__primary_orbit','maker__secondary_orbit','research__optical_orbit',
      'common__inhabited_ground','common__maker_spine','common__research_spine','common__north_spine']
    assert all(x in baseline for x in must)
    residual={}
    for role,scene in [('maker',nm),('research',nr)]:
        residual[role]=[n for n in scene if n.startswith(role+'__')]
        assert not residual[role]
        # The supports persist, proving the form isn't actually derived from activity.
        assert all(n in scene for n in baseline if n.startswith('common__'))
    assert nm and nr and baseline
    ratios={role:round(len(scene)/len(baseline),4) for role,scene in [('no_maker',nm),('no_research',nr)]}
    b=real_bbox(baseline)
    bbox={role:real_bbox(scene) for role,scene in [('no_maker',nm),('no_research',nr)]}
    # Not a whole shape equality test; outer height+plan stays unchanged.
    assert all(np.allclose(b,bbox[role],atol=1e-3) for role in bbox), 'Counterfactual envelope changed; reassess morphology'
    eyes={'arrival':(0,-30,2.1),'shared':(-4,-13,2.1)}
    # For a sightline to an instrument, the instrument itself is excluded by prefix.
    rays={eye:{role:hits(point,target,baseline,exclude=(role+'__','common__terrain','common__inhabited_ground',
      'common__public_threshold')) for role,target in m['targets'].items()}
      for eye,point in eyes.items()}
    # The broad base surface and people are excluded from route centerline tests.
    # Outputs all collisions rather than assuming clearance.
    course={}
    for name,pts in m['routes'].items():
        fail=[]
        for i,(a,c) in enumerate(zip(pts,pts[1:])):
            h=hits(a,c,baseline,exclude=('common__terrain','common__inhabited_ground',
                'common__public_threshold','common__person_'))
            if h:fail.append({'segment':i,'blockers':h})
        course[name]=fail
    # Sampled polar clearance witnesses at route waypoints. NOT continuous 3D body sweep.
    # Return blockers rather than asserting a universal zero.
    sampled={}
    for route,pts in m['routes'].items():
        blockers=[]
        for i,p in enumerate(pts):
            for z in (p[2]-.85,p[2]+.25):
                for theta in range(8):
                    b2=[p[0]+.55*math.cos(theta*math.tau/8),p[1]+.55*math.sin(theta*math.tau/8),z]
                    a2=[p[0],p[1],z]
                    h=hits(a2,b2,baseline,exclude=('common__terrain','common__inhabited_ground',
                        'common__public_threshold','common__person_'))
                    if h:blockers.append({'point':i,'z':z,'theta':theta,'blocks':h})
        sampled[route]=blockers
    # Sky ray and floor witness, again local exact triangles.
    sky={n:hits((p[0],p[1],2), (p[0],p[1],60),baseline,exclude=('common__terrain','common__inhabited_ground','common__public_threshold'))
      for n,p in [('entrance',(0,-27)),('civic',(0,-3)),('maker',(-14,-8)),('research',(12,-7))]}
    for key,node in [('maker','maker__primary_orbit'),('research','research__optical_orbit')]:
        assert node in baseline
    return {'stage':'D30','scope':'SAVED_GLB_LOCAL_GEOMETRY_DIAGNOSTIC','cases_loaded':3,
      'node_counts':{'baseline':len(baseline),'no_maker':len(nm),'no_research':len(nr)},
      'role_residue':residual,'variant_node_ratio':ratios,
      'overall_aabb_baseline':b,'overall_aabb_in_counterfactuals':bbox,
      'activity_removal_changes_macro_envelope':False,
      'retained_common_fins_after_activity_removal':True,
      'sightline_triangle_blockers':rays,'route_centerline_triangle_blockers':course,
      'sampled_8_directions_2_heights_per_waypoint_blockers':sampled,
      'representative_vertical_sky_blockers':sky,
      'actual_indoor_rooms':'NOT_MODELED','real_weather_protection':'NOT_VERIFIED',
      'load_transfer':'NOT_CALCULATED','vertical_access':'NOT_MODELED',
      'whole_body_sweep':'NOT_RUN','formal_QA':'NOT_RUN',
      'rendering':'FROM_RELOADED_GLB','art':'NO_ADOPTION_REQUIRES_HUMAN_IMAGE_REVIEW',
      'adopted':0,'construction':'FORBIDDEN'}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',default='d30_build')
    o=Path(parser.parse_args().out)
    m=json.loads((o/'manifest.json').read_text())
    b=meshes(o/'d30_baseline.glb');nm=meshes(o/'d30_no_maker.glb');nr=meshes(o/'d30_no_research.glb')
    result=evaluate(m,b,nm,nr)
    passed=0
    for case in ('fake_art_adoption','remove_target_ring','maker_role_residue','erase_counterfactual_envelope'):
        doc=copy.deepcopy(m);a=b.copy();x=nm.copy();y=nr.copy()
        if case=='fake_art_adoption':doc['limits']['adopted']=1
        if case=='remove_target_ring':a.pop('research__optical_orbit')
        if case=='maker_role_residue':x['maker__primary_orbit']=b['maker__primary_orbit']
        if case=='erase_counterfactual_envelope':x.pop('common__north_spine')
        try:evaluate(doc,a,x,y)
        except (AssertionError,KeyError):passed+=1
        else:raise AssertionError(case+' not detected')
    assert passed==4
    result['negative_controls_detected']=passed
    (o/'d30_independent_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('D30 audit, 4/4 mutations detected. These checks do not certify art/safety.')
    print('rays',result['sightline_triangle_blockers'])
    print('routes',result['route_centerline_triangle_blockers'])
    print('sampled blocker counts',{k:len(v) for k,v in result['sampled_8_directions_2_heights_per_waypoint_blockers'].items()})
if __name__=='__main__':main()
