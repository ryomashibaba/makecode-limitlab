"""D30 -- apparatus-as-architecture, local true 3D, exploratory ART HOLD.

Rebuilds 3 GLB variants and renders actual RELOADED baseline GLB (VTK).
Not Minecraft construction, full building design, or formal QA.
"""
import argparse, json, math
from pathlib import Path
import numpy as np
import trimesh

C={'site':(196,198,189,255),'stone':(132,146,139,255),'floor':(220,206,178,255),
   'fin':(95,129,133,255),'fin2':(133,153,149,255),'metal':(45,75,89,255),
   'copper':(196,123,78,255),'light':(238,199,124,255),'glass':(104,200,206,255),
   'maker':(221,147,89,255),'research':(101,182,198,255),'plant':(76,132,108,255),
   'person':(192,91,70,255),'paper':(226,223,201,255)}
VIEW={
 '01_overview':((75,-90,69),(1,3,12),52),
 '02_approach':((0,-32,2.1),(0,6,10),72),
 '03_activity':((-4,-13,2.1),(0,3,9),77),
 '04_maker_eye':((-15,-10,2.1),(-7,5,7),73),
 '05_research_eye':((13,-7,2.1),(2,9,8),74),
 '06_altitude':((-59,55,42),(0,0,12),54)}
SCENES={'entrance':(0,-30,1.8),'demonstration':(-4,-13,1.8),
        'maker':(-14,-8,1.8),'research':(12,-7,1.8),'exchange':(0,10,1.8)}
TARGETS={'maker':(-9,5,7.3),'research':(4,9,8.4)}
ROUTES={'public_spine':[(0,-31,1.85),(0,-24,1.85),(-1,-16,1.85),(0,-7,1.85),(0,0,1.85),(0,13,1.85)],
 'maker_branch':[(0,-15,1.85),(-4,-10,1.85),(-9,-8,1.85),(-14,-8,1.85)],
 'research_branch':[(0,-12,1.85),(5,-10,1.85),(9,-7,1.85),(12,-7,1.85)]}

def add(s,n,g,role):
    assert n not in s.graph.nodes, n
    g.visual.vertex_colors=np.tile(np.asarray(C[role],dtype=np.uint8),(len(g.vertices),1))
    s.add_geometry(g,node_name=n,geom_name=n)

def cube(s,n,center,size,role):
    g=trimesh.creation.box(extents=size);g.apply_translation(center);add(s,n,g,role)

def link(s,n,a,b,r,role,sections=16):
    aa=np.array(a,float);bb=np.array(b,float);d=bb-aa
    g=trimesh.creation.cylinder(radius=r,height=float(np.linalg.norm(d)),sections=sections)
    g.apply_transform(trimesh.geometry.align_vectors([0,0,1],d));g.apply_translation((aa+bb)/2)
    add(s,n,g,role)

def ring(s,n,center,major,minor,role,tilt,seg=96,tube=12):
    # Fully triangulated 3D annular device with noncoplanar frame; NOT an art illustration.
    verts=[];faces=[]
    center=np.asarray(center,float)
    R=trimesh.transformations.euler_matrix(*tilt)[:3,:3]
    for i in range(seg):
        a=i*2*math.pi/seg
        for j in range(tube):
            b=j*2*math.pi/tube
            rr=major+minor*math.cos(b)
            point=np.array([rr*math.cos(a),rr*math.sin(a),minor*math.sin(b)])
            verts.append(center+R@point)
    for i in range(seg):
        for j in range(tube):
            a=i*tube+j; b=i*tube+(j+1)%tube;c=((i+1)%seg)*tube+j;d=((i+1)%seg)*tube+(j+1)%tube
            faces.extend([[a,c,b],[b,c,d]])
    add(s,n,trimesh.Trimesh(vertices=np.asarray(verts),faces=faces,process=False),role)

def sweep_fin(s,n,positions,rxs,rys,role):
    # Closed, thick, curved load-path hypothesis. Tapered and rooted in the ground.
    p=np.asarray(positions,float);vv=[];ff=[];sides=12
    for i,pt in enumerate(p):
        d=p[min(i+1,len(p)-1)]-p[max(i-1,0)]
        t=d/np.linalg.norm(d)
        a=np.cross(t,[0,0,1.])
        if np.linalg.norm(a)<1e-6:a=np.cross(t,[0,1.,0])
        a/=np.linalg.norm(a);b=np.cross(t,a);b/=np.linalg.norm(b)
        for j in range(sides):
            z=2*math.pi*j/sides
            vv.append(pt+a*math.cos(z)*rxs[i]+b*math.sin(z)*rys[i])
    for i in range(len(p)-1):
        for j in range(sides):
            a=i*sides+j;b=i*sides+(j+1)%sides;c=(i+1)*sides+j;d=(i+1)*sides+(j+1)%sides
            ff.extend([[a,c,b],[b,c,d]])
    for j in range(1,sides-1):ff.extend([[0,j,j+1],[sides*(len(p)-1),sides*(len(p)-1)+j+1,sides*(len(p)-1)+j]])
    add(s,n,trimesh.Trimesh(vertices=vv,faces=ff,process=False),role)

def build(case):
    s=trimesh.Scene()
    cube(s,'common__terrain',(0,0,-1.25),(70,76,2.5),'site')
    cube(s,'common__inhabited_ground',(0,0,.15),(42,55,.3),'floor')
    cube(s,'common__public_threshold',(0,-32,.17),(11,12,.34),'floor')
    # Biased urban canyon boundary with gaps, NOT paired roof plates.
    # Each fin begins in a site bearing foot, changes direction, and shades a distinct activity.
    fins=[('common__north_spine',[(19,22,0.8),(22,20,7),(20,17,15),(14,12,23),(10,9,30)], [3.6,3.3,2.8,2.1,1.0],[3.3,3.2,2.5,1.7,.8]),
          ('common__maker_spine',[(-22,-17,0.8),(-24,-10,7),(-19,-3,16),(-12,1,24),(-8,5,28)], [3.8,3.3,2.6,1.8,1.0],[3.8,2.8,2.5,1.7,.8]),
          ('common__research_spine',[(23,-9,.8),(25,-3,8),(21,4,17),(15,10,22),(13,14,24)], [3.8,3.1,2.5,1.8,.9],[3.3,2.8,2.2,1.4,.7]),
          ('common__south_spur',[(-23,22,.8),(-21,18,8),(-17,16,14),(-11,15,19),(-7,13,21)], [3.6,3.0,2.5,1.5,.8],[3.2,2.6,2.0,1.3,.6])]
    for n,p,a,b in fins:sweep_fin(s,n,p,a,b,'fin')
    # Parts of the public program are deep/recessed into the real rooted fins, not generic boxes.
    for i,(x,y) in enumerate([(-14,20),(-19,11),(17,19),(20,-8)]):
        cube(s,f'common__civic_seat_{i}',(x,y,.7),(3.4,2.0,1.2),'stone')
    # Central apparatus, not a minor equipment icon. Activity generates the urban void.
    if case!='no_maker':
        ring(s,'maker__primary_orbit',(0,5,14),10.7,.62,'copper',(math.pi*.35,math.pi*.06,math.pi*.18))
        ring(s,'maker__secondary_orbit',(0,5,14),8.8,.38,'metal',(math.pi*.53,math.pi*.26,math.pi*.22))
        cube(s,'maker__fabrication_foundation',(-9,4,1.1),(8,7,1.7),'maker')
        for i in range(5):
            link(s,f'maker__loom_strand_{i}',(-11+i*.8,4,2.8),(-8+i*1.2,5+i*.4,19+i*.3),.16,'light')
        link(s,'maker__load_bearing_mast',(-8,5,1.8),(-7,5,20),.55,'metal')
        for j in range(3):cube(s,f'maker__stock_table_{j}',(-15,4+j*6,1.0),(4,2.4,1.2),'maker')
    if case!='no_research':
        # Public science instrumentation shares the *same* atmospheric field and volume.
        ring(s,'research__optical_orbit',(3,9,12),5.4,.40,'glass',(math.pi*.24,math.pi*.34,math.pi*.47),seg=64)
        cube(s,'research__observation_station',(10,8,1.35),(5.5,8,2.1),'research')
        for i in range(4):
            link(s,f'research__radiant_sensor_{i}',(8+i*.8,9,2.3),(7+i*.2,10+i*.5,8),.13,'metal')
        for i in range(3):cube(s,f'research__lab_bench_{i}',(12,14+i*3.1,1.2),(4,2.2,1.7),'research')
    for i,(x,y) in enumerate([(0,-23),(0,-14),(-3,-8),(4,-3),(-2,13),(6,19)]):
        link(s,f'common__person_{i}',(x,y,.3),(x,y,1.9),.30,'person',sections=10)
    for i,(x,y) in enumerate([(-18,-23),(17,27),(-18,29)]):
        cube(s,f'common__plant_basin_{i}',(x,y,.7),(3.6,3.4,1.4),'stone')
        link(s,f'common__green_stem_{i}',(x,y,1.1),(x,y,5),.35,'plant')
    return s

def render_saved(path,out):
    import vtk
    s=trimesh.load(path,force='scene',process=False)
    for name,(eye,target,angle) in VIEW.items():
        ren=vtk.vtkRenderer();ren.SetBackground(.88,.92,.93)
        win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(1120,720);win.AddRenderer(ren)
        for node in s.graph.nodes_geometry:
            T,k=s.graph[node];g=s.geometry[k].copy();g.apply_transform(T)
            pts=vtk.vtkPoints()
            for v in g.vertices:pts.InsertNextPoint(*[float(x) for x in v])
            polys=vtk.vtkCellArray()
            for face in g.faces:
                tri=vtk.vtkTriangle()
                for i,x in enumerate(face):tri.GetPointIds().SetId(i,int(x))
                polys.InsertNextCell(tri)
            p=vtk.vtkPolyData();p.SetPoints(pts);p.SetPolys(polys)
            m=vtk.vtkPolyDataMapper();m.SetInputData(p)
            a=vtk.vtkActor();a.SetMapper(m)
            col=np.asarray(g.visual.vertex_colors)
            if len(col):a.GetProperty().SetColor(*(col.mean(axis=0)[:3]/255).tolist())
            a.GetProperty().SetAmbient(.3)
            if '__optical_orbit' in node:a.GetProperty().SetOpacity(.6)
            ren.AddActor(a)
        light=vtk.vtkLight();light.SetPosition(-35,-40,65);light.SetIntensity(1.2)
        ren.AddLight(light)
        cam=ren.GetActiveCamera();cam.SetPosition(*eye);cam.SetFocalPoint(*target)
        cam.SetViewUp(0,0,1);cam.SetViewAngle(angle)
        ren.ResetCameraClippingRange();win.Render()
        w=vtk.vtkWindowToImageFilter();w.SetInput(win);w.Update()
        writer=vtk.vtkPNGWriter();writer.SetFileName(str(out/(name+'.png')))
        writer.SetInputConnection(w.GetOutputPort());writer.Write();win.Finalize()
        print(name)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',default='d30_build');a=ap.parse_args()
    o=Path(a.out);o.mkdir(parents=True,exist_ok=True)
    m={'stage':'B11-R5 D30','name':'Public Loom Fold / 公共織機の襞',
       'scope':'LOCAL_INHABITED_APPARATUS_TRUE_3D_RESEARCH',
       'scenes':SCENES,'routes':ROUTES,'targets':TARGETS,'views':VIEW,'cases':{},
       'limits':{'art':'ART HOLD','adopted':0,'G0':'NOT_RUN','S1_G1_G2_G3':'NOT_RUN',
          'full_body_sweep':'NOT_RUN','structural_calculation':'NOT_RUN',
          'vertical_circulation':'NOT_MODELED','construction':'FORBIDDEN',
          'city_integration':'FORBIDDEN','main':'UNTOUCHED','PR53':'OPEN_DRAFT'}}
    for case in ('baseline','no_maker','no_research'):
        s=build(case);p=o/f'd30_{case}.glb';p.write_bytes(s.export(file_type='glb'))
        m['cases'][case]={'file':p.name,'nodes':len(s.graph.nodes_geometry),'faces':sum(len(g.faces) for g in s.geometry.values())}
    (o/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    render_saved(o/'d30_baseline.glb',o)
    print('D30 local three true-3D GLBs rendered from reloaded baseline. No art approval.')
if __name__=='__main__':main()
