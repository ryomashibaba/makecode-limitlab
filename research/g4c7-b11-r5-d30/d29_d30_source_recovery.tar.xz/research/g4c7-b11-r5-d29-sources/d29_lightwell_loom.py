"""D29 LIGHTWELL LOOM: one human-scaled, ground-connected civic scene.
No Minecraft construction, ART PASS, formal G0/S1/G1/G2/G3, structural certification.
One source produces 3 actual GLB variants and images from the RELOADED baseline GLB.
"""
import argparse, json, math
from pathlib import Path
import numpy as np
import trimesh

PALETTE={'site':(198,202,198,255),'floor':(216,209,186,255),
 'civic':(231,213,181,255),'fabric':(189,168,139,255),'deep':(48,75,87,255),
 'metal':(66,101,111,255),'roof':(176,199,191,255),'copper':(185,116,76,255),
 'water':(91,156,171,255),'research':(105,194,202,255),'maker':(229,150,82,255),
 'green':(73,133,108,255),'paper':(232,229,208,255),'glass':(165,225,229,144),
 'person':(199,97,86,255),'light':(243,219,140,255)}
SCENES={'arrival':(0,-30,1.8),'shared':(0,-16,1.8),
 'maker_door':(-12,-12,1.8),'maker_station':(-21,-4,2.4),
 'research_door':(12,-12,1.8),'research_station':(21,-3,3.2),
 'learning':(0,12,1.8)}
# In reality this is human-scale first-pass spatial morphology, all coordinates in author units.
ROUTES={
 'arrival_maker':[[0,-34,1.8],[0,-24,1.8],[-3,-18,1.8],[-8,-14,1.8],[-12,-10,1.8]],
 'arrival_research':[[0,-34,1.8],[0,-24,1.8],[3,-18,1.8],[8,-14,1.8],[12,-10,1.8]],
 'arrival_learning':[[0,-34,1.8],[0,-24,1.8],[0,-14,1.8],[0,0,1.8],[0,12,1.8]],
}
VIEWS={'01_overview':((74,-85,64),(0,-3,3),47),
       '02_civic_arrival':((0,-31,2.1),(0,2,4),70),
       '03_sharing_eye':((0,-18,2.1),(0,0,4),83),
       '04_making_eye':((-11,-14,2.1),(-21,-3,3.2),72),
       '05_research_eye':((11,-14,2.1),(21,-3,3.5),72),
       '06_side_oblique':((-68,-44,38),(0,0,5),48)}

def add(s,name,mesh,role):
    color=np.asarray(PALETTE[role],dtype=np.uint8)
    mesh.visual.vertex_colors=np.tile(color,(len(mesh.vertices),1))
    s.add_geometry(mesh,node_name=name,geom_name=name)

def box(s,n,at,ext,role):
    m=trimesh.creation.box(extents=ext);m.apply_translation(at);add(s,n,m,role)

def cylinder(s,n,at,r,h,role,sections=24):
    m=trimesh.creation.cylinder(radius=r,height=h,sections=sections)
    m.apply_translation(at);add(s,n,m,role)

def torus(s,n,at,major,minor,role,tube=12,segments=42,axis='z'):
    # Three-dimensional instrument ring assembled as a watertight triangulated surface.
    verts=[];faces=[]
    for i in range(segments):
        a=2*math.pi*i/segments
        for j in range(tube):
            b=2*math.pi*j/tube
            R=major+minor*math.cos(b)
            if axis=='y':p=[R*math.cos(a),minor*math.sin(b),R*math.sin(a)]
            else:p=[R*math.cos(a),R*math.sin(a),minor*math.sin(b)]
            verts.append(np.array(at)+p)
    for i in range(segments):
        for j in range(tube):
            a=i*tube+j;b=i*tube+(j+1)%tube
            c=((i+1)%segments)*tube+j;d=((i+1)%segments)*tube+(j+1)%tube
            faces.extend([[a,c,b],[b,c,d]])
    add(s,n,trimesh.Trimesh(vertices=verts,faces=faces,process=False),role)

def link(s,n,start,end,radius,role):
    a=np.array(start,float);b=np.array(end,float);v=b-a;L=np.linalg.norm(v)
    m=trimesh.creation.cylinder(radius=radius,height=L,sections=12)
    T=trimesh.geometry.align_vectors([0,0,1],v)
    m.apply_transform(T);m.apply_translation((a+b)/2)
    add(s,n,m,role)

def polygon(s,n,pts,z,thickness,role):
    # Polygonal prism via 2D triangulation / manual ear clipping using shapely triangulate.
    from shapely.geometry import Polygon as SP, Point
    from shapely.ops import triangulate
    shape=SP(pts);assert shape.is_valid and shape.area>0
    coords=list(shape.exterior.coords)[:-1];k=len(coords)
    verts=[[x,y,z] for x,y in coords]+[[x,y,z+thickness] for x,y in coords]
    faces=[]
    # Triangulations use polygon vertices only (convex author surfaces).
    from shapely.ops import triangulate as sh_tri
    for t in sh_tri(shape):
        if not shape.covers(t.representative_point()):continue
        ids=[]
        for x,y in list(t.exterior.coords)[:3]:
            ids.append(min(range(k), key=lambda i:math.hypot(x-coords[i][0],y-coords[i][1])))
        if len(set(ids))!=3:continue
        ax,ay=coords[ids[0]];bx,by=coords[ids[1]];cx,cy=coords[ids[2]]
        if (bx-ax)*(cy-ay)-(by-ay)*(cx-ax)<0:ids[1],ids[2]=ids[2],ids[1]
        faces.append([ids[2],ids[1],ids[0]]);faces.append([i+k for i in ids])
    for i in range(k):
        j=(i+1)%k;faces.extend([[i,j,j+k],[i,j+k,i+k]])
    add(s,n,trimesh.Trimesh(vertices=verts,faces=faces,process=False),role)

def roof_patch(s,n,poly,zbase,zvar,role):
    # Each part is a DIFFERENT non-planar warped ruled panel, not a repeated ceiling slab.
    cx=sum(x for x,y in poly)/len(poly);cy=sum(y for x,y in poly)/len(poly)
    k=len(poly);bottom=[[x,y,zbase+0.7*math.sin(.19*x+.11*y)+zvar*(x-cx)/20] for x,y in poly]
    top=[[x,y,z+.40] for x,y,z in bottom]
    vv=bottom+top;ff=[]
    for j in range(1,k-1):ff.extend([[0,j+1,j],[k,k+j,k+j+1]])
    for j in range(k):
        t=(j+1)%k;ff.extend([[j,t,t+k],[j,t+k,j+k]])
    add(s,n,trimesh.Trimesh(vertices=vv,faces=ff,process=False),role)

def civic(s):
    box(s,'common__site_ground',(0,0,-1.0),(86,86,2),'site')
    polygon(s,'common__continuous_foundation',
      [(-30,-27),(25,-29),(33,-17),(33,22),(19,31),(-19,29),(-32,17)],.02,.26,'floor')
    polygon(s,'common__front_threshold',[(-7,-39),(7,-39),(8,-25),(-8,-25)],.03,.18,'civic')
    polygon(s,'common__open_cultural_court',[(-12,-23),(12,-23),(14,5),(11,14),(-11,14),(-14,4)],.30,.09,'civic')
    # Material changes are IN the single floor, not floating elevated terraces.
    for i,(x,y) in enumerate([(-5,-21),(2,-21),(-2,-13),(5,-13),(-4,-4),(4,4)]):
        polygon(s,f'common__floor_inlay_{i}',[(x-2,y-1),(x+2,y-1),(x+2.1,y+1.2),(x-2,y+1.1)],.40,.07,'fabric')
    # A learning station and shared gathering bench are directly beside the path.
    box(s,'common__learning_counter',(0,20,1.0),(12,1.5,1.4),'fabric')
    for i,(x,y) in enumerate([(-8,8),(8,9),(-7,17),(8,17)]):
        box(s,f'common__reading_stand_{i}',(x,y,1.02),(2.4,1.1,1.35),'paper')
        link(s,f'common__stand_pole_{i}',(x,y,.40),(x,y,3.3),.12,'metal')
    # A single central light well (OPEN to actual sky), not a fake 3D hole in a roof.
    torus(s,'common__sunlight_indicator',(0,0,.55),6.8,.22,'copper')
    # Subtle planted edge does not block the central walking network.
    for i,(x,y) in enumerate([(-8,-26),(9,-27),(-4,24),(7,25)]):
        cylinder(s,f'common__green_planter_{i}',(x,y,.8),1.05,.7,'fabric')
        for j in range(3):
            cylinder(s,f'common__plant_{i}_{j}',(x+.3*math.cos(j*2),y+.3*math.sin(j*2),1.7),.22,1.9,'green')

def maker(s):
    polygon(s,'maker__floor_area',[(-31,-20),(-12,-20),(-11,17),(-25,19),(-34,6)],.28,.1,'maker')
    # Back is a sequence of short, faceted insulated wall parts, leaving FRONT actually empty.
    for i,(a,b) in enumerate(zip([(-33,-18),(-34,-3),(-32,9),(-25,18)],[(-34,-3),(-32,9),(-25,18),(-13,18)])):
        link(s,f'maker__masonry_{i}',(*a,4.1),(*b,4.1),1.4,'deep')
    for j,xy in enumerate([(-31,-20),(-31,9),(-24,18),(-12,14)]):
        x,y=xy;cylinder(s,f'maker__rooted_support_{j}',(x,y,4.5),.60,9.0,'metal')
    roof_patch(s,'maker__shelter_wing_0',[(-33,-20),(-10,-20),(-12,-9),(-34,-7)],9.1,1.1,'roof')
    roof_patch(s,'maker__shelter_wing_1',[(-34,-7),(-12,-9),(-10,8),(-31,10)],10.1,-1.8,'roof')
    roof_patch(s,'maker__shelter_wing_2',[(-31,10),(-10,8),(-11,18),(-25,19)],11.4,2.8,'roof')
    # fabrication machine has separate frame, gantry, cutting stage and raw stock.
    box(s,'maker__actual_machine_base',(-22,-5,1.1),(7.5,5,1.5),'deep')
    for i,x in enumerate([-24.9,-18.9]):
        for j,y in enumerate([-6.8,-3.2]):link(s,f'maker__machine_pillar_{i}_{j}',(x,y,1.7),(x,y,4.1),.13,'metal')
    link(s,'maker__gantry_cross',(-25.1,-5.1,4.15),(-18.9,-5.1,4.15),.19,'copper')
    link(s,'maker__nozzle',(-21.5,-5.1,4.1),(-21.5,-5.1,2.45),.14,'maker')
    box(s,'maker__worktable',(-23,6,1.1),(6.8,3,1.35),'fabric')
    for i in range(6):
        box(s,f'maker__material_sample_{i}',(-26+i*1.05,6,2.1),(.58,.65,.85+i*.13),'maker')
    torus(s,'maker__spindle_art',(-23,6,3.8),1.3,.15,'copper',axis='y')

def research(s):
    polygon(s,'research__floor_area',[(12,-20),(31,-20),(35,-5),(32,12),(21,21),(11,15)],.28,.1,'research')
    for j,(a,b) in enumerate(zip([(32,-19),(35,-5),(32,12),(21,21)],[(35,-5),(32,12),(21,21),(12,17)])):
        link(s,f'research__curved_shell_wall_{j}',(*a,4.5),(*b,4.5),1.45,'deep')
    for j,(x,y) in enumerate([(31,-19),(33,6),(22,20),(12,14)]):
        cylinder(s,f'research__rooted_support_{j}',(x,y,4.8),.58,9.6,'metal')
    roof_patch(s,'research__shelter_wing_0',[(11,-20),(31,-20),(35,-6),(11,-8)],9.5,-1.0,'roof')
    roof_patch(s,'research__shelter_wing_1',[(11,-8),(35,-6),(32,10),(12,10)],11.3,2.1,'roof')
    roof_patch(s,'research__shelter_wing_2',[(12,10),(32,10),(21,21),(12,17)],10.3,-1.9,'roof')
    # experiment equipment uses a three-dimensional intersecting ring, sensor array, real bench.
    cylinder(s,'research__central_test_pedestal',(23,-3,1.25),1.8,1.65,'metal')
    torus(s,'research__instrument_ring',(23,-3,4.4),2.25,.17,'research',axis='y')
    torus(s,'research__instrument_inner_ring',(23,-3,4.4),1.3,.13,'copper',axis='y')
    link(s,'research__spectrometer_lateral',(21,-3,4.4),(25,-3,4.4),.16,'light')
    for j in range(4):
        y=-11+j*4.6
        box(s,f'research__optical_bench_{j}',(28,y,1.0),(3,1.2,1.2),'fabric')
        cylinder(s,f'research__sensor_{j}',(28,y,2.2),.36,1.4,'research')

def human_figures(s):
    for i,(x,y) in enumerate([(0,-23),(-4,-10),(5,-12),(-7,11),(6,18)]):
        cylinder(s,f'common__visitor_body_{i}',(x,y,1.25),.36,1.5,'person',12)
        m=trimesh.creation.icosphere(subdivisions=1,radius=.31);m.apply_translation((x,y,2.25));add(s,f'common__visitor_head_{i}',m,'paper')

def build(case):
    s=trimesh.Scene();civic(s)
    if case!='no_maker':maker(s)
    if case!='no_research':research(s)
    human_figures(s)
    return s

def render(saved,out):
    import vtk
    s=trimesh.load(saved,force='scene',process=False)
    for title,(eye,target,angle) in VIEWS.items():
        ren=vtk.vtkRenderer();ren.SetBackground(.87,.93,.94)
        ren.SetUseDepthPeeling(True)
        window=vtk.vtkRenderWindow();window.SetOffScreenRendering(1)
        window.SetMultiSamples(4)
        window.AddRenderer(ren);window.SetSize(1200,720)
        actors=0
        for node in s.graph.nodes_geometry:
            t,n=s.graph[node];g=s.geometry[n].copy();g.apply_transform(t)
            if len(g.faces)==0:continue
            points=vtk.vtkPoints()
            for v in g.vertices:points.InsertNextPoint(*map(float,v))
            faces=vtk.vtkCellArray()
            for f in g.faces:
                tri=vtk.vtkTriangle()
                for k,v in enumerate(f):tri.GetPointIds().SetId(k,int(v))
                faces.InsertNextCell(tri)
            data=vtk.vtkPolyData();data.SetPoints(points);data.SetPolys(faces)
            norms=vtk.vtkPolyDataNormals();norms.SetInputData(data);norms.ConsistencyOn();norms.Update()
            mapper=vtk.vtkPolyDataMapper();mapper.SetInputConnection(norms.GetOutputPort())
            act=vtk.vtkActor();act.SetMapper(mapper)
            color=np.asarray(g.visual.vertex_colors).mean(axis=0)
            act.GetProperty().SetColor(*(color[:3]/255).tolist())
            act.GetProperty().SetAmbient(.30)
            act.GetProperty().SetDiffuse(.68)
            act.GetProperty().SetSpecular(.13)
            if 'glass' in str(node):act.GetProperty().SetOpacity(.45)
            ren.AddActor(act);actors+=1
        sun=vtk.vtkLight();sun.SetLightTypeToSceneLight();sun.SetPosition(-35,-42,65)
        sun.SetFocalPoint(0,0,0);sun.SetIntensity(.85);ren.AddLight(sun)
        cam=ren.GetActiveCamera();cam.SetPosition(*eye);cam.SetFocalPoint(*target)
        cam.SetViewUp(0,0,1);cam.SetViewAngle(angle)
        ren.ResetCameraClippingRange();window.Render()
        wi=vtk.vtkWindowToImageFilter();wi.SetInput(window);wi.Update()
        writer=vtk.vtkPNGWriter();writer.SetFileName(str(out/(title+'.png')))
        writer.SetInputConnection(wi.GetOutputPort());writer.Write()
        window.Finalize()
        print('rendered',title,'actors',actors)

def main():
    a=argparse.ArgumentParser();a.add_argument('--out',default='d29_build');arg=a.parse_args()
    out=Path(arg.out);out.mkdir(parents=True,exist_ok=True)
    manifest={'stage':'B11-R5 D29','type':'LOCAL_HUMAN_SCALE_TRUE_3D_RESEARCH',
       'model':'Lightwell Loom / 光の織庭', 'cases':{},
       'scenes':SCENES,'routes':ROUTES,
       'protection':{'ART':'HOLD','adopted':0,'G0':'NOT_RUN','S1_G1_G2_G3':'NOT_RUN',
       'body_sweep':'NOT_RUN','structure':'NOT_RUN','vertical_lift':'NOT_MODELED',
       'construction':'FORBIDDEN','integration':'FORBIDDEN','PR53':'DRAFT_OPEN','main':'UNTOUCHED'}}
    for case in ('baseline','no_maker','no_research'):
        s=build(case);f=out/f'd29_{case}.glb';f.write_bytes(s.export(file_type='glb'))
        manifest['cases'][case]={'glb':f.name,'nodes':len(s.graph.nodes_geometry),'triangles':sum(len(g.faces) for g in s.geometry.values())}
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    render(out/'d29_baseline.glb',out)
    print('D29 3 saved GLBs, 6 reloaded-render camera views; NO ART PASS / NO CONSTRUCTION.')
if __name__=='__main__':main()
