"""Independent saved-GLB D29 research audit; does NOT import D29 generator.
Simple true-triangle line segments, sampled witness rays. No continuous body-sweep,
no structural, accessibility, fire, weather, or artistic certification.
"""
import argparse, json, copy, math
from pathlib import Path
import numpy as np
import trimesh

def load_scene(path):
    s=trimesh.load(path,force='scene',process=False)
    d={}
    for node in s.graph.nodes_geometry:
        T,n=s.graph[node]
        g=s.geometry[n].copy();g.apply_transform(T);d[str(node)]=g
    return d

def hit_mesh(start,end,mesh):
    start=np.asarray(start,float);end=np.asarray(end,float);direction=end-start
    tri=mesh.triangles
    if len(tri)==0:return False
    a,b,c=tri[:,0],tri[:,1],tri[:,2]
    E1=b-a;E2=c-a
    h=np.cross(np.broadcast_to(direction,E2.shape),E2)
    det=np.einsum('ij,ij->i',E1,h)
    valid=np.abs(det)>1e-10
    if not valid.any():return False
    inv=np.zeros_like(det);inv[valid]=1/det[valid]
    f=start-a;U=inv*np.einsum('ij,ij->i',f,h)
    q=np.cross(f,E1)
    V=inv*np.einsum('ij,j->i',q,direction)
    T=inv*np.einsum('ij,ij->i',E2,q)
    return bool(np.any(valid&(U>=-1e-7)&(V>=-1e-7)&(U+V<=1+1e-7)&(T>1e-4)&(T<1-1e-4)))

def hits(a,b,meshes,ignore=()):
    return [name for name,m in meshes.items() if not name.startswith(tuple(ignore)) and hit_mesh(a,b,m)]

def validate(base,no_maker,no_research,manifest):
    baseline_names=set(base)
    prot=manifest['protection']
    assert manifest['stage']=='B11-R5 D29'
    assert prot=={'ART':'HOLD','adopted':0,'G0':'NOT_RUN',
       'S1_G1_G2_G3':'NOT_RUN','body_sweep':'NOT_RUN','structure':'NOT_RUN',
       'vertical_lift':'NOT_MODELED','construction':'FORBIDDEN',
       'integration':'FORBIDDEN','PR53':'DRAFT_OPEN','main':'UNTOUCHED'}
    assert manifest['type']=='LOCAL_HUMAN_SCALE_TRUE_3D_RESEARCH'
    assert all(k in manifest['cases'] for k in ['baseline','no_maker','no_research'])
    important=['common__continuous_foundation','common__open_cultural_court',
               'maker__floor_area','research__floor_area',
               'maker__actual_machine_base','research__instrument_ring',
               'maker__shelter_wing_0','research__shelter_wing_0']
    assert all(k in baseline_names for k in important)
    role_residue={}
    for removed_role,other in (('maker',no_maker),('research',no_research)):
        role_residue[removed_role]=sorted(k for k in other if k.startswith(removed_role+'__'))
        assert not role_residue[removed_role]
        assert all(k in other for k in baseline_names if not k.startswith(removed_role+'__'))
    assert set(base)!=set(no_maker)!=set(no_research)
    # A 3D ray, not a claim about entire human visual field.
    eyes={'arrival':[0,-31,2.1],'shared':[0,-18,2.1]}
    targets={'maker':[-21,-3,3.1],'research':[21,-3,3.5]}
    rays={eye:{role:hits(origin,target,base,ignore=(role+'__','common__site_ground','common__continuous_foundation','common__open_cultural_court','common__front_threshold','common__floor_inlay'))
        for role,target in targets.items()} for eye,origin in eyes.items()}
    sky={}
    for name,eye in {'central':[0,-8,1.8],'arrival':[0,-29,1.8],'making_front':[-12,-12,1.8],'research_front':[12,-12,1.8]}.items():
        sky[name]=hits(eye,[eye[0],eye[1],80],base,
            ignore=('common__site_ground','common__continuous_foundation','common__open_cultural_court','common__front_threshold','common__floor_inlay'))
    paths=manifest['routes']; centerline_hits={}
    for name,waypoints in paths.items():
        blocked={}
        for i,(p,q) in enumerate(zip(waypoints,waypoints[1:])):
            block=hits(p,q,base,ignore=('common__', 'maker__floor_area','research__floor_area'))
            if block:blocked[str(i)]=block
        centerline_hits[name]=blocked
    # a restricted base-level vertical witness, NOT sweeping an entire human volume.
    floor_witness={}
    floors={k:v for k,v in base.items() if k.endswith('floor_area') or k in ('common__continuous_foundation','common__open_cultural_court','common__front_threshold')}
    for id,p in {'maker':[-20,1,1.8],'research':[20,1,1.8],'shared':[0,-10,1.8]}.items():
        floor_witness[id]=hits(p,[p[0],p[1],-4],floors)
    roof_names=[k for k in baseline_names if '__shelter_wing_' in k]
    # This counts only generated planar projections, not engineering load or weather coverage.
    candidate={'stage':'D29','scope':'SAVED_GLB_INDEPENDENT_LIMITED_RAYS',
       'actual_glbs_loaded':3,'nodes':{x:len(d) for x,d in [('baseline',base),('no_maker',no_maker),('no_research',no_research)]},
       'role_removal_residue':role_residue,'public_eye_to_activity_triangle_blockers':rays,
       'open_sky_representative_rays':sky,'ground_centerline_triangle_blockers':centerline_hits,
       'floor_presence_witnesses':floor_witness,
       'shelter_roof_panel_count':len(roof_names),
       'actual_indoor_weather_seal':'NOT_VERIFIED',
       'body_radius_clearance_sweep':'NOT_RUN',
       'vertical_access':'NOT_MODELED',
       'structural_support_calculation':'NOT_RUN',
       'formal_G0_S1_G1_G2_G3':'NOT_RUN',
       'author_image_review':'PRE-G0 ART REJECT - thin canopy/pavilion grammar repeated',
       'adopted':0,'overall':'ART HOLD','minecraft_construction':'FORBIDDEN'}
    assert candidate['shelter_roof_panel_count']==6
    assert all(floor_witness.values())
    assert not sky['central'], 'central explicit sky ray no longer clear'
    return candidate

def main():
    a=argparse.ArgumentParser();a.add_argument('--out',default='d29_build');o=Path(a.parse_args().out)
    m=json.loads((o/'manifest.json').read_text(encoding='utf-8'))
    b=load_scene(o/'d29_baseline.glb');nm=load_scene(o/'d29_no_maker.glb');nr=load_scene(o/'d29_no_research.glb')
    r=validate(b,nm,nr,m)
    # Negative controls must detect corrupted custody and activity-removal failures.
    tests=0
    for corrupt in ('false_art_adoption','maker_removal_fake','research_removal_fake','missing_common_floor'):
        bb,xx,yy,mm=b.copy(),nm.copy(),nr.copy(),copy.deepcopy(m)
        if corrupt=='false_art_adoption':mm['protection']['adopted']=1
        if corrupt=='maker_removal_fake':xx['maker__actual_machine_base']=bb['maker__actual_machine_base']
        if corrupt=='research_removal_fake':yy['research__instrument_ring']=bb['research__instrument_ring']
        if corrupt=='missing_common_floor':bb.pop('common__continuous_foundation')
        try:validate(bb,xx,yy,mm)
        except (AssertionError,KeyError):tests+=1
        else:raise AssertionError('Negative mutation was not detected: '+corrupt)
    r['negative_controls_detected']=tests
    (o/'d29_independent_result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('D29 saved true-GLB limited audit and 4 mutations PASS; visual ART REJECT separate.')
    print('PUBLIC RAYS',r['public_eye_to_activity_triangle_blockers'])
    print('PATH CENTERS',r['ground_centerline_triangle_blockers'])
if __name__=='__main__':main()
